CREATE VIEW sys.`x$schema_flattened_keys` AS
  SELECT
    `information_schema`.`statistics`.`TABLE_SCHEMA`                                 AS `table_schema`,
    `information_schema`.`statistics`.`TABLE_NAME`                                   AS `table_name`,
    `information_schema`.`statistics`.`INDEX_NAME`                                   AS `index_name`,
    max(`information_schema`.`statistics`.`NON_UNIQUE`)                              AS `non_unique`,
    max(if(isnull(`information_schema`.`statistics`.`SUB_PART`), 0, 1))              AS `subpart_exists`,
    group_concat(`information_schema`.`statistics`.`COLUMN_NAME` ORDER BY
                 `information_schema`.`statistics`.`SEQ_IN_INDEX` ASC SEPARATOR ',') AS `index_columns`
  FROM `information_schema`.`statistics`
  WHERE ((`information_schema`.`statistics`.`INDEX_TYPE` = 'BTREE') AND
         (`information_schema`.`statistics`.`TABLE_SCHEMA` NOT IN
          ('mysql', 'sys', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')))
  GROUP BY `information_schema`.`statistics`.`TABLE_SCHEMA`, `information_schema`.`statistics`.`TABLE_NAME`,
    `information_schema`.`statistics`.`INDEX_NAME`;
